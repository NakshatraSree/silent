package com.example.sielent;


import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private AudioManager audioManager;

    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);

        Button silentButton = findViewById(R.id.silentButton);
        Button normalButton = findViewById(R.id.normalButton);

        silentButton.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View v) {
                if (isNotificationPolicyAccessGranted()) {
                    // Put the phone in silent mode
                    audioManager.setRingerMode(AudioManager.RINGER_MODE_SILENT);

                    // Check if the phone is in silent mode
                    if (audioManager.getRingerMode() == AudioManager.RINGER_MODE_SILENT) {
                        // Phone is in silent mode
                        showToast("Silent mode activated");
                    } else {
                        // Phone is not in silent mode
                        showToast("Failed to activate silent mode");
                    }
                } else {
                    // Ask the user to grant permission to change Do Not Disturb mode
                    Intent intent = new Intent(android.provider.Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS);
                    startActivity(intent);
                }

            }
        });

        normalButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Set the phone back to the normal ringer mode
                audioManager.setRingerMode(AudioManager.RINGER_MODE_NORMAL);
                // Show a toast message to indicate normal mode activation
                showToast("Normal mode activated");
            }
        });
    }

    private boolean isNotificationPolicyAccessGranted() {
        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        return notificationManager.isNotificationPolicyAccessGranted();
    }

    private void showToast(String message) {
        Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();
    }
}
